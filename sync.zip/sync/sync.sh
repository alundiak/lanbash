#!/bin/bash
echo "2"
# Synchronization between indoCode and SoftServe changes
# Script to initial setup BSCA codebase

# Setup Middleware configuration 
BOOT_CONFIG="/home/jenkins/KonyOneServer/install/middleware/middleware-bootconfig/"
CONF=$BOOT_CONFIG"configurations/"
echo $CONF

cp .gitignore ../
cp ant-contrib-0.6.jar ../
cp prebuild.xml ../
cp env ../env/

rm ../services/java/lib/bsca.jar
cp bsca_dec_27.jar ../services/java/lib/

rm ../services/xml/lib/bsca.jar
cp bsca_dec_27.jar ../services/xml/lib/

cp readme.txt ../web_module/
cp readme.txt ../resources/mobile/native/android/en_US/


