#!/bin/bash
#
# Bash script for initial setup project/application with Git
#

#
# This in case if git-svn
#

#git rm -rf --cached jssrc
#git rm --cached upgrade_actions_*.properties middleware.properties build.properties context.properties defaults/defaults.properties lua_widget_m4_info.properties
# #git update-index --assume-unchanged context.properties defaults/defaults.properties lua_widget_m4_info.properties
# #git reset --hard # this for not to commit above svn changes, to perform them only locally.

#
# This is for pure Git
#
# Better to set to store password, if u r lazy :) to type pass all the time
git config --global credential.helper store

# git config --global credential.helper cache
# git config --global credential.helper 'cache --timeout=3600'
# git config --global credential.helper = 'C:\\Path\\To\\Your\\Downloaded\\File\\git-credential-winstore.exe'
# git config credential.helper '$shortname -f AUTHFILE1 -f AUTHFILE2'
# Details: http://stackoverflow.com/questions/6031214/git-how-to-use-netrc-file-on-windows-to-save-user-and-password

# better to set false. Details: http://jenyay.net/Git/Autocrlf
git config core.autocrlf false

FL="Andrii Lundiak"
EMAIL=alund@softserveinc.com
echo "Type your First and Last name (will be used as value for 'git config user.name')"
read FL_1
if [ "$FL_1" != "" ]; then
	FL="$FL_1";
fi
git config user.name "$FL"

echo "Type your email (will be used as value for 'git config user.email')"
read EMAIL_1
if [ "$EMAIL_1" != "" ]; then
	EMAIL="$EMAIL_1";
fi
git config user.email "$EMAIL"

echo "here is what you have now:"
git config -l
